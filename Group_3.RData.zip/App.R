

library(shiny)


ui <- fluidPage("Prospect Rundown", 
                numericInput(inputId = "num", label = "Round Selected", value = 2, min = 1, max = 7),
                numericInput(inputId = "num1", label = "Pick Selected", value = 2, min = 1, max = 256),
                numericInput(inputId = "num2", label = "Age", value = 20, min = 20, max = 27),
                numericInput(inputId = "num3", label = "AP1", value = 2, min = 0, max = 3),
                numericInput(inputId = "num4", label = "PB", value = 2, min = 0, max = 17),
                numericInput(inputId = "num5", label = "St", value = 2, min = 0, max = 6),
                plotOutput("hist"))

server <- function(input, output) {
  output$hist <- renderPlot({hist(rnorm(input$num))})
}

shinyApp(ui = ui, server = server)











































